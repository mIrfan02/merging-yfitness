<?php
/**
* Language file for group management form text
*
*/
return array(

    'name'			=> 'Nome do Gurpo',
    'slug'          => 'Slug',
    'general' 		=> 'Geral',
    'permissions'	=> 'Permissões',

);
