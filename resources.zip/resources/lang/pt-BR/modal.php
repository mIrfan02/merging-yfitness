<?php

/**
 * Language file for delete modal
 *
 */
return array(

    'title'         => 'Apagare item',
    'body'			=> 'Tem certeza que quer apagar esse item? Essa operação é irreversível.',
    'cancel'		=> 'Cancelar',
    'confirm'		=> 'Apagar',

);
