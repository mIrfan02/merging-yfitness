<?php

/**
* Language file for blog delete modal
*
*/
return array(

    'body'			=> 'Da li ste sigurni da �elite obrisati ovaj blog? Nakon ove operacije nije mogu?e vratiti podatke.',
    'cancel'		=> 'Odustani',
    'confirm'		=> 'Obri�i',
    'title'         => 'Obri�i blog',

);
