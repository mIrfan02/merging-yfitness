<?php
/**
* Language file for user section titles
*
*/

return array(

	'user_profile'			=> 'Profil korisnika',
	'first_name'			=> 'Ime',
	'last_name'				=> 'Prezime',
	'email'					=> 'E-mail',
	'phone'					=> 'Broj telefona',
	'address'				=> 'Adresa',
	'city'					=> 'Grad',
	'status'				=> 'Status',
	'created_at'			=> 'Kreiran',
    'select_image'			=> 'Izaberite sliku',
    'gender'				=> 'Pol',
    'dob'					=> 'Datum ro?enja',
    'country'				=> 'Dr�ava',
    'state'					=> 'Grad',
    'postal'				=> 'Po�tanski broj'
    
);
