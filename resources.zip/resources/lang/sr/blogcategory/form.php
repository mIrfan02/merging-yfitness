<?php
/**
* Language file for group management form text
*
*/
return array(

    'name'			=> 'Naziv kategorije bloga',
    'general' 		=> 'Op�te',
);
