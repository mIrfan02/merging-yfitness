<?php
/**
* Language file for submit buttons across the site
*
*/
return array(

    'edit'    			=> 'Bearbeiten',
    'delete'  			=> 'Löschen',
    'restore' 			=> 'Wiederherstellen',
    'publish' 			=> 'Veröffentlichen',
    'save'	  			=> 'Speichern',
    'submit'	  		=> 'einreichen',
    'cancel'  			=> 'Abbrechen',
    'create'  			=> 'Erstellen',
    'back'    			=> 'Zurück',
    'signin'  			=> 'Anmelden',
    'forgotpassword' 	=> 'Ich habe mein Passwort vergessen',
    'rememberme'		=> 'Passwort merken',
    'signup'			=> 'Eintragen',
    'update'			=> 'Update',

);
