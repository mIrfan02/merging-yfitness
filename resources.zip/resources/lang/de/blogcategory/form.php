<?php
/**
* Language file for group management form text
*
*/
return array(

    'name'			=> 'Blog Kategorie Name',
    'general' 		=> 'Allgemein',
);
