<?php
/**
* Language file for group table headings
*
*/

return array(

    'id'         => 'Id',
    'name'       => 'Name',
    'users'      => 'nzahl Benutzer',
    'created_at' => 'Erstellt am',
    'actions'	 => 'Aktionen',

);
