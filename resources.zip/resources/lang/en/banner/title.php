<?php
/**
* Language file for banner section titles
*
*/

return array(

	'title'			=> 'Title',
	'create' => 'Create New Banner',
	'edit' => 'Edit Banner',
	'management' => 'Manage Banner',
	'add-banner' => 'Add New Banner',
	'banner' => 'Banner',
	'banners' => 'Banners',
	'bannerlist' => 'Banners List',
	'bannerdetail' => 'Banner Details',
	'comments' => 'COMMENTS',
	'leavecomment' => 'LEAVE A COMMENT',


);
