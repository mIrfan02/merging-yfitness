<?php
/**
* Language file for group table headings
*
*/

return array(

    'id'         => 'Id',
    'name'       => 'Name',
    'users'      => 'No. of Users',
    'created_at' => 'Created at',
    'actions'	 => 'Actions',

);
