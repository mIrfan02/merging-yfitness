<?php
/**
* Language file for banner category table headings
*
*/

return array(

    'id'         => 'Id',
    'gender'         => 'Gender',
    'language'         => 'Language',
    'age_range'         => 'Age Range',
    'fitness_goal'         => 'Fitness Goal',
    'course'         => 'Course',
    'date'         => 'Date',
    'link'         => 'Link',
    'notification_text'         => 'Text',
    'status'         => 'Status',
    'title'       => 'Title',
    'banner'       => 'Banner',
    'comments'      => 'No. of Comments',
    'created_at' => 'Created at',
    'actions'	 => 'Actions',
    'view-banner-comment' => 'view banner & comments',
    'update-banner' => 'update banner',
    'delete-banner' => 'delete banner'

);
