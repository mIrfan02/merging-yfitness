<?php
/**
* Language file for notification section form
*
*/

return array(

	'course' => 'Course',
	'training' => 'Select Training',
	'training-goal' => 'Training Goal',
	'gender' => 'Gender',
	'language' => 'Language',
	'time' => 'Time',
	'date' => 'Date',
	'age-range' => 'Age Range',
	'text' => 'Notification Text',
    'link' => 'Link',
    'change' => 'Change',
    'publish' => 'Publish',
    'discard' => 'Discard',


);
