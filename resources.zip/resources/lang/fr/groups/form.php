<?php
/**
* Language file for group management form text
*
*/
return array(

    'name'			=> 'Nom du groupe',
    'slug'          => 'Slug',
    'general' 		=> 'General',
    'permissions'	=> 'Permissions',

);
