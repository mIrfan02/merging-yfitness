<?php

/**
* Language file for blog delete modal
*
*/
return array(

    'body'			=> 'Вы точно уверены в том, что хотите удалить этот Блог? Эта операция позже не сможет быть отменена.',
    'cancel'		=> 'Отменить',
    'confirm'		=> 'Удалить',
    'title'         => 'Удалить Блог',

);
