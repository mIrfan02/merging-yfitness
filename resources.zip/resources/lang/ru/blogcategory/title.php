<?php
/**
* Language file for blog section titles
*
*/

return array(

	'title'			=> 'Заголовок',
    'create'			=> 'Создать новую категорию блога',
    'edit' 				=> 'Редактировать категорию блога',
    'management'	=> 'Управление Категориями Блогов',
    
);
