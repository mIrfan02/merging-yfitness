<?php
/**
* Language file for blog category table headings
*
*/

return array(

    'id'         => 'Id',
    'title'       => 'Título',
    'comments'      => 'N° de Comentarios',
    'created_at' => 'Creado el',
    'actions'	 => 'Acciones',

);
