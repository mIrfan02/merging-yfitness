<?php
/**
* Language file for group management form text
*
*/
return array(

    'name'			=> 'Nombre de la Categoría del Blog',
    'general' 		=> 'General',
);
