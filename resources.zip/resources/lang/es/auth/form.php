<?php
/**
* Language file for form fields for user account management
*
*/

return array(

    'password'				=> 'Contraseña',
    'email'					=> 'Email',
    'newemail'				=> 'Email Nuevo',
    'confirmemail'			=> 'Confirmar Email',
    'firstname'				=> 'Nombre',
    'lastname'				=> 'Apellido',
    'newpassword'			=> 'Contraseña Nueva',
    'website'				=> 'Sitio Web',
    'country'				=> 'País',
    'gravataremail'			=> 'Email de Gravatar',
    'changegravatar'		=> 'Cambiar su avatar en Gravatar.com',
    'oldpassword'			=> 'Contraseña Actual',
    'confirmpassword'		=> 'Confirmar Contraseña',

);
