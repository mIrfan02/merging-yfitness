<?php
/**
* Language file for group management form text
*
*/
return array(

    'name'			=> 'Nombre del Grupo',
    'slug'          => 'Slug',
    'general' 		=> 'General',
    'permissions'	=> 'Permisos',

);
