<?php
/**
* Language file for banner category table headings
*
*/

return array(

    'id'         => 'Id',
    'title'       => 'Title',
    'banner'       => 'Banner',
    'comments'      => 'No. of Comments',
    'created_at' => 'Created at',
    'actions'	 => 'Actions',
    'view-banner-comment' => 'view banner & comments',
    'update-banner' => 'update banner',
    'delete-banner' => 'delete banner'

);
