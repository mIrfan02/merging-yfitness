<?php
/**
* Language file for notification section titles
*
*/

return array(

	'title'			=> 'Title',
	'create' => 'Create New Notification',
	'edit' => 'Edit Notification',
	'management' => 'Manage Notification',
	'add-notification' => 'Add New Notification',
	'notification' => 'Notification',
	'notifications' => 'Notifications',
	'notificationlist' => 'Notifications List',
	'notificationdetail' => 'Notification Details',
	'comments' => 'COMMENTS',
	'leavecomment' => 'LEAVE A COMMENT',


);
